var searchData=
[
  ['genericextensionmethods',['GenericExtensionMethods',['../d4/dee/a00008.html',1,'Bohrium::Core::Extensions']]]
];
