var searchData=
[
  ['match',['Match',['../d2/de7/a00014.html#a394e56926ec1ba3514c1e1ec0ddaa2d9',1,'Bohrium::Core::Extensions::RegexExtensionMethods']]],
  ['matches',['Matches',['../d2/de7/a00014.html#a280a99d1618fa6cf52632d582881bc67',1,'Bohrium::Core::Extensions::RegexExtensionMethods']]]
];
