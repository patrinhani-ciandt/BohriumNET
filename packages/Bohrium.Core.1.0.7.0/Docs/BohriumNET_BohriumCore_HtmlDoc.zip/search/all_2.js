var searchData=
[
  ['callmethod',['CallMethod',['../d7/dd4/a00013.html#a9f8e53885741a83856c92d80661f0156',1,'Bohrium::Core::Extensions::ReflectionExtensionMethods']]],
  ['callstaticmethod',['CallStaticMethod',['../d7/dd4/a00013.html#ac71bb965371687e0a6be028fa8b99abb',1,'Bohrium::Core::Extensions::ReflectionExtensionMethods']]],
  ['capitalize',['Capitalize',['../dd/d1b/a00015.html#a085868b846ae151a6eca8b5dc6545170',1,'Bohrium::Core::Extensions::StringExtensionMethods']]],
  ['castto_3c_20t_20_3e',['CastTo&lt; T &gt;',['../df/d86/a00012.html#a6b07c24a436818fc3c193be28c76834a',1,'Bohrium::Core::Extensions::ObjectExtensionMethods']]],
  ['coalescedbnull_3c_20t_20_3e',['CoalesceDBNull&lt; T &gt;',['../df/d86/a00012.html#a9257ff04807389c1bc9f57f00b025e8a',1,'Bohrium.Core.Extensions.ObjectExtensionMethods.CoalesceDBNull&lt; T &gt;(this object value, T alternative)'],['../df/d86/a00012.html#aeb1ce2e7d9597815897922d6b4e49955',1,'Bohrium.Core.Extensions.ObjectExtensionMethods.CoalesceDBNull&lt; T &gt;(this object value)']]],
  ['compress',['Compress',['../d1/d7c/a00003.html#a40f81e1c2c657447a404acc9d488b967',1,'Bohrium.Core.Compression.CompressionUtils.Compress()'],['../d8/d84/a00001.html#aca428d8a4fc12e1a3b61b01f4d91cfa3',1,'Bohrium.Core.Extensions.ByteArrayExtensionMethods.Compress()']]],
  ['compressionutils',['CompressionUtils',['../d1/d7c/a00003.html',1,'Bohrium::Core::Compression']]],
  ['computemd5hash',['ComputeMD5Hash',['../df/d86/a00012.html#aa3d13027bf21b0927f50c48b558e1be9',1,'Bohrium::Core::Extensions::ObjectExtensionMethods']]],
  ['containslike',['ContainsLike',['../dd/d1b/a00015.html#aae69802b3bd8da6cea47f77f2e50ff2d',1,'Bohrium::Core::Extensions::StringExtensionMethods']]],
  ['containsvalue_3c_20tk_2c_20tv_20_3e',['ContainsValue&lt; TK, TV &gt;',['../da/da0/a00009.html#a10ef96cad9da427823f437b392bab419',1,'Bohrium::Core::Extensions::IDictionaryExtensionMethods']]],
  ['copypropertiesfrom',['CopyPropertiesFrom',['../df/d86/a00012.html#ae1dedcf89c7eda3365df7e2fc9e2dc02',1,'Bohrium.Core.Extensions.ObjectExtensionMethods.CopyPropertiesFrom(this object target, object source)'],['../df/d86/a00012.html#aa520bf61d20298d4fb950317fbadbfba',1,'Bohrium.Core.Extensions.ObjectExtensionMethods.CopyPropertiesFrom(this object target, object source, params string[] ignoreProperties)']]],
  ['copyto',['CopyTo',['../dd/dad/a00005.html#a0081b4331539b4d76854670567ea2b82',1,'Bohrium::Core::Extensions::DirectoryInfoExtensionMethods']]]
];
