var searchData=
[
  ['safecast_3c_20t_20_3e',['SafeCast&lt; T &gt;',['../df/d86/a00012.html#ad40e8f00d8ff31568ee774258f7f6bf7',1,'Bohrium::Core::Extensions::ObjectExtensionMethods']]],
  ['setfieldvalue',['SetFieldValue',['../d7/dd4/a00013.html#a464e76ad22fb387138b5d0163de588be',1,'Bohrium::Core::Extensions::ReflectionExtensionMethods']]],
  ['setpropertyvalue',['SetPropertyValue',['../d7/dd4/a00013.html#a1274f9584de33443865ddaa01fe78c5b',1,'Bohrium::Core::Extensions::ReflectionExtensionMethods']]],
  ['settime',['SetTime',['../d0/d0b/a00004.html#afb5a6a9f11f2bcbe22c420b2d20b2c0e',1,'Bohrium::Core::Extensions::DateTimeExtensionMethods']]],
  ['shallowcopy',['ShallowCopy',['../df/d86/a00012.html#a7543e05a04dae25b8872edfb0dc23e90',1,'Bohrium::Core::Extensions::ObjectExtensionMethods']]],
  ['split',['Split',['../dd/d1b/a00015.html#abaf8f81acae5796fbabb96b934dee8b3',1,'Bohrium::Core::Extensions::StringExtensionMethods']]],
  ['striphtml',['StripHtml',['../dd/d1b/a00015.html#ac4f222731b480cc0ba7d5c95e96722f6',1,'Bohrium::Core::Extensions::StringExtensionMethods']]]
];
