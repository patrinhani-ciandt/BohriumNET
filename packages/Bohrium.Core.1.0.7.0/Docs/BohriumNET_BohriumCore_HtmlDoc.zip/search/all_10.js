var searchData=
[
  ['unsafecast_3c_20t_20_3e',['UnsafeCast&lt; T &gt;',['../df/d86/a00012.html#a47cec98fae0ea48008f2d5f70d13fd8b',1,'Bohrium::Core::Extensions::ObjectExtensionMethods']]]
];
