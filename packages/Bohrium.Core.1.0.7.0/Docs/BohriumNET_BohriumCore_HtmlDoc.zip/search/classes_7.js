var searchData=
[
  ['reflectionextensionmethods',['ReflectionExtensionMethods',['../d7/dd4/a00013.html',1,'Bohrium::Core::Extensions']]],
  ['regexextensionmethods',['RegexExtensionMethods',['../d2/de7/a00014.html',1,'Bohrium::Core::Extensions']]]
];
