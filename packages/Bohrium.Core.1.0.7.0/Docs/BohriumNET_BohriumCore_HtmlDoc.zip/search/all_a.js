var searchData=
[
  ['nextweekdayofmonth',['NextWeekDayOfMonth',['../d0/d0b/a00004.html#a00f419383359bb09bd826c56a3f998fc',1,'Bohrium::Core::Extensions::DateTimeExtensionMethods']]],
  ['nullifempty',['NullIfEmpty',['../dd/d1b/a00015.html#ac58093cfcc2772dc13c1b64f52ef2052',1,'Bohrium::Core::Extensions::StringExtensionMethods']]]
];
