var searchData=
[
  ['datetimeextensionmethods',['DateTimeExtensionMethods',['../d0/d0b/a00004.html',1,'Bohrium::Core::Extensions']]],
  ['directoryinfoextensionmethods',['DirectoryInfoExtensionMethods',['../dd/dad/a00005.html',1,'Bohrium::Core::Extensions']]]
];
