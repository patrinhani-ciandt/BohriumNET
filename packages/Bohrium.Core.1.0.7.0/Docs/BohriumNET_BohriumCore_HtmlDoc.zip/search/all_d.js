var searchData=
[
  ['reflectionextensionmethods',['ReflectionExtensionMethods',['../d7/dd4/a00013.html',1,'Bohrium::Core::Extensions']]],
  ['regexdelete',['RegexDelete',['../dd/d1b/a00015.html#afd8cfff1091745ca1ae90f5041a68ac0',1,'Bohrium::Core::Extensions::StringExtensionMethods']]],
  ['regexextensionmethods',['RegexExtensionMethods',['../d2/de7/a00014.html',1,'Bohrium::Core::Extensions']]],
  ['regexreplace',['RegexReplace',['../dd/d1b/a00015.html#a710d9eb4afe0e37f83ca1a5b33f78425',1,'Bohrium::Core::Extensions::StringExtensionMethods']]]
];
