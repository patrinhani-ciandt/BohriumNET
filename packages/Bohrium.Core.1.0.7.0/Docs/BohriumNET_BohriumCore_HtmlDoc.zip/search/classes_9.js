var searchData=
[
  ['typeextensionmethods',['TypeExtensionMethods',['../d7/d7a/a00016.html',1,'Bohrium::Core::Extensions']]]
];
