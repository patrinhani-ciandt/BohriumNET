var searchData=
[
  ['idictionaryextensionmethods',['IDictionaryExtensionMethods',['../da/da0/a00009.html',1,'Bohrium::Core::Extensions']]],
  ['ienumerableextensionmethods',['IEnumerableExtensionMethods',['../d7/dec/a00010.html',1,'Bohrium::Core::Extensions']]],
  ['ilistextensionmethods',['IListExtensionMethods',['../da/d45/a00011.html',1,'Bohrium::Core::Extensions']]]
];
