var searchData=
[
  ['stringextensionmethods',['StringExtensionMethods',['../dd/d1b/a00015.html',1,'Bohrium::Core::Extensions']]]
];
