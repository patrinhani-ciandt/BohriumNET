var searchData=
[
  ['eventhandlerextensionmethods',['EventHandlerExtensionMethods',['../de/d21/a00006.html',1,'Bohrium::Core::Extensions']]],
  ['exceptionextensionmethods',['ExceptionExtensionMethods',['../de/d5e/a00007.html',1,'Bohrium::Core::Extensions']]]
];
